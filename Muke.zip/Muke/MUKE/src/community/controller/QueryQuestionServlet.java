package community.controller;

import javax.servlet.annotation.WebServlet;

@WebServlet("/QueryQuestion.action") public class QueryQuestionServlet {

}
